# État qualité — NOTION BUSINESS OS

Dernière mise à jour : 17 octobre 2026

## Contrôles exécutés dans l'environnement de travail

- `node scripts/verify-project.mjs` : **64/64 contrôles statiques réussis**.
- `node scripts/verify-assets.mjs` : **10/10 ressources privées présentes et valides**.
- `unzip -t notion-business-os-web-starter.zip` : archive ZIP valide, sans erreur d'intégrité.
- Le workflow GitHub Actions `.github/workflows/quality.yml` lance les vérifications puis `npm run build` lors d'un push ou d'une pull request. Il a été ajouté au projet, mais n'a pas encore été exécuté sur GitHub.

## Contrôles non exécutés / non certifiés

- `npm install --ignore-scripts --no-audit --no-fund` a expiré après 180 secondes dans cet environnement. Les dépendances n'ont donc pas pu être installées ici.
- `npm run build` : **non confirmé** tant que l'installation des dépendances n'a pas réussi.
- Tests fonctionnels dans un navigateur réel, sur mobile et ordinateur.
- Connexion/inscription testées contre un vrai projet Supabase.
- Test d'isolation RLS avec deux comptes Supabase distincts.
- Exécution du schéma SQL et du test de sécurité sur un projet Supabase de test.
- Téléversement et test des 10 ressources dans le bucket privé réel.
- Déploiement public, domaine, paiement, mentions légales et politique de confidentialité.

## Point de sécurité à traiter avant toute vente

L'API de téléchargement vérifie actuellement que l'utilisateur est connecté avant de créer une URL signée. Cette vérification **ne prouve pas à elle seule que l'utilisateur a acheté ou est autorisé à recevoir chaque ressource**. Avant de vendre le pack, ajouter et tester une vérification de droits d'accès/entitlements par utilisateur et par ressource, ou confirmer explicitement que toutes les ressources doivent être accessibles à tout compte inscrit.

## Étapes de validation à effectuer dans l'environnement de déploiement

```bash
npm install
npm run verify
npm run build
```

Ensuite :

1. Configurer `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
2. Conserver `SUPABASE_SERVICE_ROLE_KEY` exclusivement côté serveur, dans les variables secrètes de l'hébergeur.
3. Exécuter `supabase/schema.sql` dans un projet Supabase de test.
4. Tester inscription, connexion, déconnexion, données personnelles et isolation entre deux comptes.
5. Créer le bucket privé `business-suite-assets`, importer les 10 fichiers et tester les téléchargements autorisés et refusés.
6. Ajouter la vérification d'achat/droits d'accès avant de distribuer les ressources payantes.

Ne jamais publier une clé `service_role` dans le navigateur, dans Git ou dans une archive remise aux utilisateurs.


## Mise à jour sécurité téléchargements
- Ajout du contrôle serveur des droits dans `download_entitlements` avant toute URL signée.
- Un compte connecté sans droit actif ou avec droit expiré reçoit `403`.
- Table de droits avec RLS activée et aucune policy cliente ; gestion via service role côté serveur ou SQL administrateur.
- Activation automatique via fournisseur de paiement non intégrée ; les droits doivent être attribués après vérification réelle du paiement.
- Vérifications statiques : 68/68 ; intégrité ressources : 10/10. Compilation de production toujours non confirmée tant que les dépendances ne sont pas installées et que `npm run build` n'a pas réussi.
