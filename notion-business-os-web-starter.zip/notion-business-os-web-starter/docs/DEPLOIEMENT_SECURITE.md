# Déploiement et sécurité — NOTION BUSINESS OS

## Avant de connecter Supabase

1. Créer un projet Supabase de test.
2. Dans SQL Editor, exécuter `supabase/schema.sql`.
3. Dans Authentication, définir les URL autorisées pour le développement et la production.
4. Copier `.env.example` vers `.env.local`, puis renseigner `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY` (clé publishable/anon uniquement).
5. Ne jamais exposer une clé `service_role` dans le navigateur ou dans un dépôt Git.
6. Installer les dépendances et lancer l'application localement.

## Contrôles minimum avant mise en ligne

- Confirmer que RLS est activé sur les huit tables listées dans `supabase/tests/security-smoke-test.sql` et que `supabase/tests/security-assertions.sql` se termine sans exception.
- Créer deux comptes de test A et B.
- Depuis A, créer une tâche et un contact ; vérifier que B ne peut ni les lire, ni les modifier, ni les supprimer.
- Tester l'inscription avec confirmation e-mail activée et désactivée selon le réglage choisi.
- Tester connexion, déconnexion, actualisation et expiration de session.
- Vérifier les erreurs réseau et les formulaires vides.
- Tester sur un téléphone Android, notamment les tableaux qui défilent horizontalement.
- Configurer une politique de confidentialité, des conditions d'utilisation, une adresse de support et une procédure de suppression de compte.

## État fonctionnel connu

- Interface et navigation : prototype disponible.
- Authentification Supabase : code présent, nécessite les variables d'environnement et un test réel.
- Tâches : CRUD limité à la création et au changement de statut dans le code actuel ; lecture depuis Supabase pour les utilisateurs connectés.
- CRM, projets, marketing, objectifs et ressources : encore des vues de démonstration ; ne pas présenter ces modules comme synchronisés.
- Aucun hébergement, domaine, paiement ni compte Supabase n'est configuré par ce dépôt.

## Déploiement recommandé

1. Valider le build en local avec `npm run build`.
2. Publier le dépôt dans un espace Git privé.
3. Importer le dépôt dans Vercel et configurer les deux variables publiques Supabase dans les paramètres du projet.
4. Ajouter le domaine de production aux URL autorisées de Supabase Auth.
5. Refaire les tests de sécurité et de parcours sur l'URL publique avant d'inviter des clients.

## Assertions SQL automatisées
Après avoir exécuté `supabase/schema.sql` dans un projet **de test**, exécuter `supabase/tests/security-assertions.sql`. Le script s'arrête avec une exception si une table attendue n'a pas RLS, si `download_entitlements` expose une policy, ou si une politique de propriété utilisateur attendue manque. Un résultat positif reste un contrôle de configuration : il ne remplace pas les tests d'accès avec deux comptes Auth distincts ni les tests de l'API de téléchargement.


## Administration des droits de téléchargement

Le fichier `supabase/admin-entitlements.sql` contient des modèles commentés pour accorder, vérifier et révoquer manuellement un droit après vérification du paiement. Les commandes sont laissées commentées par défaut pour éviter une exécution accidentelle. Remplacer chaque placeholder, vérifier l'UUID du compte dans `auth.users`, puis exécuter uniquement la commande voulue. L'automatisation par webhook de paiement reste à implémenter.


## Matrice de test de l’API de téléchargement

Tester `POST /api/download` dans un projet Supabase de test, avec le bucket `business-suite-assets` privé et les variables serveur configurées. Ne jamais utiliser la clé `service_role` depuis un client HTTP ou un navigateur.

| Cas | Préparation | Résultat attendu |
| --- | --- | --- |
| Sans jeton | Requête sans en-tête `Authorization` | `401` |
| Jeton invalide/expiré | Envoyer un faux jeton ou un jeton expiré | `401` |
| Corps JSON invalide | Session valide, corps non JSON | `400` |
| Identifiant inconnu | Session valide et ID absent du catalogue autorisé | `404` |
| Aucun droit actif | Session valide, aucun enregistrement d’autorisation | `403` |
| Droit expiré ou révoqué | Session valide, droit expiré ou `active = false` | `403` |
| Configuration serveur manquante | Environnement de test sans une variable nécessaire | `503` |
| Droit actif + fichier disponible | Compte de test autorisé et fichier dans le bucket privé | `200`, URL signée temporaire |
| Fichier manquant/stockage indisponible | Droit actif mais objet absent ou stockage inaccessible | `503` |

Pour chaque réponse positive, vérifier que le lien expire rapidement, que la réponse comporte `Cache-Control: no-store` et qu’aucun secret serveur n’est renvoyé. Vérifier également que le jeton d’un compte B ne permet jamais d’utiliser le droit d’un compte A.

**Critère de validation :** consigner le statut HTTP observé pour chaque scénario. Ne pas marquer cette matrice comme réussie avant de l’avoir exécutée sur l’environnement réel.
