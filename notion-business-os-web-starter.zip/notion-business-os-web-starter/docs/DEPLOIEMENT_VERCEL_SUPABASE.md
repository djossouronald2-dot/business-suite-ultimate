# Déploiement Vercel + Supabase — BUSINESS SUITE ULTIMATE

Ce guide connecte le code à un projet Supabase hébergé puis déploie l’application Next.js sur Vercel. La préparation locale ne crée pas le projet distant et ne prouve pas que les identifiants fonctionnent.

## 1. Préparer Supabase

1. Ouvrir le projet Supabase et vérifier que son URL est `https://qefmboqaqdlwqazitaiu.supabase.co`.
2. Dans **SQL Editor**, ouvrir un nouvel éditeur et exécuter le contenu de `supabase/migrations/20261017000000_initial_schema.sql`.
3. Exécuter ensuite `supabase/tests/security-assertions.sql`. Ne pas poursuivre si le script signale une erreur : examiner les politiques présentes et corriger avant d’exposer l’application.
4. Dans **Authentication → URL Configuration**, définir l’URL de site sur le domaine Vercel une fois obtenu. Ajouter les URL de redirection nécessaires, par exemple `https://TON-DOMAINE-VERCEL.vercel.app/**` si l’interface accepte les jokers. Pour les tests locaux, ajouter `http://localhost:3000/**`.
5. Conserver le bucket Storage `business-suite-assets` privé. Ne pas le rendre public.

## 2. Importer le code dans GitHub

1. Décompresser `notion-business-os-web-starter.zip`.
2. Créer un dépôt GitHub privé et téléverser le contenu du dossier `notion-business-os-web-starter/` à sa racine (le `package.json` doit être à la racine du dépôt).
3. Vérifier que `.env.local`, `node_modules/` et `.next/` ne sont pas envoyés. Le `.gitignore` du projet les exclut.
4. Attendre que l’action GitHub `Quality checks` se termine. Le build de production n’est pas certifié avant qu’un `npm run build` ait réellement réussi.

## 3. Déployer sur Vercel

1. Ouvrir https://vercel.com/new et importer le dépôt GitHub.
2. Framework preset : **Next.js** ; Root Directory : `./` si le dépôt contient directement `package.json`.
3. Dans **Environment Variables**, ajouter ces trois variables pour **Production**, **Preview** et **Development** selon les environnements utilisés :

   - `NEXT_PUBLIC_SUPABASE_URL` = `https://qefmboqaqdlwqazitaiu.supabase.co`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = la clé publique publishable/anon du projet
   - `SUPABASE_SERVICE_ROLE_KEY` = la clé secrète serveur du projet, uniquement si le code serveur et l’import de fichiers en ont besoin. Ne jamais préfixer cette variable par `NEXT_PUBLIC_` et ne jamais la commiter.

4. Cliquer **Deploy**. Si le build échoue, ouvrir les logs et corriger l’erreur réelle avant de poursuivre. Après chaque changement de variable d’environnement, redéployer pour que la nouvelle configuration soit prise en compte.
5. Copier le domaine `*.vercel.app` attribué au projet et le renseigner dans Supabase Authentication → URL Configuration.

## 4. Configurer le stockage privé

Le téléversement des dix ressources est une opération d’administration : la clé secrète ne doit pas être ajoutée au navigateur ni envoyée dans le chat.

Sur un ordinateur de confiance, dans le dossier du projet :

```bash
npm install
npm run verify
npm run build
```

Définir les trois variables ci-dessus dans l’environnement local sécurisé (par exemple dans `.env.local`, exclu de Git), puis exécuter :

```bash
npm run supabase:check-env
npm run upload:assets
```

Le script `upload:assets` crée le bucket privé s’il n’existe pas et téléverse les fichiers de `private-assets/`. Vérifier dans Supabase Storage que le bucket `business-suite-assets` est privé et contient les dix ressources attendues. Ne pas exécuter cette commande dans un terminal partagé ou sur une machine non fiable.

## 5. Vérifications avant pilote

- Créer deux comptes de test distincts.
- Vérifier inscription, connexion, déconnexion et redirection e-mail.
- Vérifier qu’un utilisateur ne peut ni lire ni modifier les données de l’autre.
- Tester `/api/download` sans session (attendu `401`), avec session mais sans droit actif (`403`) et avec un droit actif (URL signée temporaire).
- Vérifier qu’un utilisateur ne peut pas s’accorder un droit lui-même. L’attribution de droits reste manuelle après vérification du paiement ; aucun webhook de paiement automatique n’est encore intégré.
- Tester sur mobile et ordinateur. Ne pas annoncer la disponibilité commerciale avant réussite de ces tests.

## Limites actuelles

Le projet contient la préparation de la configuration, les migrations, le script d’import et l’API de téléchargement protégée. Il n’est pas possible de déclarer le projet Supabase distant configuré, le build réussi ou le site déployé tant que les actions ci-dessus n’ont pas été exécutées et vérifiées dans les comptes GitHub, Vercel et Supabase de l’utilisateur.
