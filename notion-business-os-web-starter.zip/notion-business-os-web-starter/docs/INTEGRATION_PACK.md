# BUSINESS SUITE ULTIMATE — intégration du pack

NOTION BUSINESS OS est la composante web gratuite de BUSINESS SUITE ULTIMATE. Le Pack MLM ACCÉLÉRATEUR est un produit distinct et ne doit pas apparaître dans cette bibliothèque. Les produits « 100 idées de business en ligne » et « 100 templates WhatsApp » ne font pas partie de cette suite.

## Composantes et fichiers intégrés

1. **PROSPECT PRO** — `public/downloads/PROSPECT_PRO_Premium_Avance.xlsx`
2. **FINANCE PRO** — `public/downloads/FINANCE_PRO_Premium.xlsx`
3. **STOCK PRO** — `public/downloads/STOCK_PRO_Premium.xlsx`
4. **MARKETING PRO** — `public/downloads/MARKETING_PRO_Premium.xlsx`
5. **BUSINESS MANAGER PRO** — `public/downloads/BUSINESS_MANAGER_PRO_Premium.xlsx`
6. **BUSINESS PLANNER PRO** — `public/downloads/BUSINESS_PLANNER_PRO.pdf`
7. **BUSINESS WORKBOOK PRO** — `public/downloads/BUSINESS_WORKBOOK_PRO.pdf`
8. **MARKETING DESIGN KIT PRO** — catalogue `public/downloads/MARKETING_DESIGN_KIT_PRO_Catalogue_45_Modeles.pdf` et guide Canva `public/downloads/MARKETING_DESIGN_KIT_PRO_Guide_Canva.pdf`
9. **AI PROMPT LIBRARY** — `public/downloads/AI_PROMPT_LIBRARY_100_PROMPTS_PREMIUM.pdf`
10. **NOTION BUSINESS OS** — application web gratuite. Le déploiement public et la connexion Supabase restent à finaliser.

## Notes

- Les dix ressources source sont conservées dans `private-assets/`; le script `npm run upload:assets` les envoie dans le bucket privé Supabase. La bibliothèque passe par l’API de liens signés.
- La présence des fichiers dans le dépôt ne garantit pas encore la compilation ou le bon fonctionnement du téléchargement après déploiement ; effectuer un build et un test navigateur avant diffusion.
- Les fichiers sont servis comme ressources publiques statiques si l’application est déployée telle quelle. Si le pack doit être réservé à des acheteurs ou membres, mettre en place un stockage privé et des liens signés avant de le publier.
