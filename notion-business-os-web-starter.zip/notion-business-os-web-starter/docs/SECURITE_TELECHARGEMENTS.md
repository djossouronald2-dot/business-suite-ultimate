# Sécurité des téléchargements de BUSINESS SUITE ULTIMATE

## Architecture
- Les dix fichiers source résident dans `private-assets/`, hors du répertoire public Next.js.
- `npm run upload:assets` les téléverse vers le bucket Supabase Storage `business-suite-assets`, créé avec `public: false`.
- L'API `POST /api/download` accepte uniquement une liste blanche d'identifiants, valide le bearer token via `auth.getUser`, puis crée une URL signée valable 90 secondes.
- Le navigateur obtient le jeton de session depuis Supabase et demande l'URL signée. Le secret `SUPABASE_SERVICE_ROLE_KEY` n'est utilisé que dans la route serveur et le script d'upload.
- Avant de signer une URL, la route vérifie côté serveur une ligne active dans `download_entitlements` pour `business-suite-ultimate`. Un compte connecté sans droit reçoit 403. La table n'expose aucune policy RLS aux clients.

## Contrôles manuels obligatoires
1. Sans `Authorization: Bearer ...`, l'API renvoie 401.
2. Avec un jeton invalide, l'API renvoie 401.
3. Avec un identifiant de fichier inconnu, l'API renvoie 404.
4. Avec une session valide sans droit actif, l'API renvoie 403.
5. Avec un droit actif mais stockage non configuré ou fichier absent, l'API renvoie 503.
6. Avec un droit actif et un fichier téléversé, l'API renvoie une URL signée temporaire.
7. L'URL signée expire après 90 secondes ; vérifier qu'un accès public direct au bucket est impossible.

## Activation manuelle d’un achat
Après avoir vérifié le paiement dans votre système de paiement, un administrateur peut utiliser le runbook `supabase/admin-entitlements.sql` dans l’éditeur SQL Supabase. Les commandes d’action sont volontairement commentées : vérifiez l’UUID Auth et la référence de paiement, remplacez les placeholders, puis décommentez uniquement la commande nécessaire. Le fichier inclut l’attribution, la vérification et la révocation :



Consultez le fichier `supabase/admin-entitlements.sql` pour les commandes modèles commentées.


Ne jamais donner à l’application cliente un accès direct en écriture à cette table. L’intégration du fournisseur de paiement et l’activation automatique restent à développer.
