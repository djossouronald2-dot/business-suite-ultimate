import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ASSETS: Record<string, string> = {
  'prospect-pro': 'PROSPECT_PRO_Premium_Avance.xlsx',
  'finance-pro': 'FINANCE_PRO_Premium.xlsx',
  'stock-pro': 'STOCK_PRO_Premium.xlsx',
  'marketing-pro': 'MARKETING_PRO_Premium.xlsx',
  'business-manager-pro': 'BUSINESS_MANAGER_PRO_Premium.xlsx',
  'business-planner-pro': 'BUSINESS_PLANNER_PRO.pdf',
  'business-workbook-pro': 'BUSINESS_WORKBOOK_PRO.pdf',
  'marketing-design-catalogue': 'MARKETING_DESIGN_KIT_PRO_Catalogue_45_Modeles.pdf',
  'marketing-design-canva-guide': 'MARKETING_DESIGN_KIT_PRO_Guide_Canva.pdf',
  'ai-prompt-library': 'AI_PROMPT_LIBRARY_100_PROMPTS_PREMIUM.pdf',
};
const BUCKET = 'business-suite-assets';

export async function POST(request: NextRequest) {
  const authorization = request.headers.get('authorization') || '';
  const token = authorization.startsWith('Bearer ') ? authorization.slice(7) : '';
  if (!token) return NextResponse.json({ error: 'Authentification requise.' }, { status: 401 });

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !anonKey || !serviceRoleKey) {
    return NextResponse.json({ error: 'Le stockage privé n’est pas encore configuré.' }, { status: 503 });
  }

  const authClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: authError } = await authClient.auth.getUser(token);
  if (authError || !userData.user) return NextResponse.json({ error: 'Session invalide. Reconnectez-vous.' }, { status: 401 });

  let id = '';
  try {
    const body = await request.json();
    id = typeof body?.id === 'string' ? body.id : '';
  } catch {
    return NextResponse.json({ error: 'Requête invalide.' }, { status: 400 });
  }
  const filename = ASSETS[id];
  if (!filename) return NextResponse.json({ error: 'Ressource inconnue.' }, { status: 404 });

  const adminClient = createClient(url, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } });
  // An authenticated account is not proof of purchase: verify a server-managed entitlement.
  const { data: entitlement, error: entitlementError } = await adminClient
    .from('download_entitlements')
    .select('id')
    .eq('user_id', userData.user.id)
    .eq('product_key', 'business-suite-ultimate')
    .eq('active', true)
    .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
    .maybeSingle();
  if (entitlementError) {
    return NextResponse.json({ error: 'Impossible de vérifier les droits d’accès.' }, { status: 503 });
  }
  if (!entitlement) {
    return NextResponse.json({ error: 'Accès non autorisé. Vérifiez que votre achat a été activé.' }, { status: 403 });
  }

  const { data, error } = await adminClient.storage.from(BUCKET).createSignedUrl(filename, 90, { download: filename });
  if (error || !data?.signedUrl) {
    return NextResponse.json({ error: 'Ressource indisponible. Vérifiez le stockage privé.' }, { status: 503 });
  }
  return NextResponse.json({ url: data.signedUrl, expiresIn: 90 }, { headers: { 'Cache-Control': 'no-store' } });
}
