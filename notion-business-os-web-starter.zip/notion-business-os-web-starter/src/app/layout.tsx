import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'NOTION BUSINESS OS', description: 'Pilotez votre activité en un seul espace.' };
export default function RootLayout({ children }: Readonly<{children: React.ReactNode}>) { return <html lang="fr"><body>{children}</body></html>; }
