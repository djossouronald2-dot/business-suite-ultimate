# NOTION BUSINESS OS — Web App starter

Prototype responsive en français pour piloter une petite activité : tableau de bord, CRM, tâches, projets, marketing, objectifs/KPI et ressources.

## Démarrer en local
1. Installer Node.js LTS.
2. Exécuter `npm install`.
3. Copier `.env.example` vers `.env.local`.
4. Pour le mode connecté, créer un projet Supabase et renseigner l'URL et la clé publique `anon`/publishable dans `.env.local`.
5. Exécuter `npm run dev`, puis ouvrir http://localhost:3000.

## Base de données Supabase
Exécuter `supabase/schema.sql` dans le SQL Editor du projet Supabase. Le schéma active les politiques Row Level Security (RLS) pour isoler les données par utilisateur. Vérifier les règles avec les étapes de `docs/DEPLOIEMENT_SECURITE.md` et le script de diagnostic `supabase/tests/security-smoke-test.sql`.

## État actuel — transparence
- Interface responsive et navigation entre sept modules.
- Inscription/connexion Supabase dans le code, si les variables sont configurées.
- Tâches : chargement depuis Supabase pour un utilisateur connecté, création et changement de statut ; en mode démo, les tâches sont stockées dans le `localStorage` du navigateur.
- CRM, projets, marketing, objectifs et ressources : vues de démonstration, pas encore synchronisées avec la base.
- Ce dépôt ne contient aucune configuration réelle de projet Supabase, aucun domaine, aucun hébergement et aucun paiement.

## Avant commercialisation
Ne pas vendre cette version comme un SaaS terminé. Il faut connecter et tester les modules restants, exécuter un build de production, vérifier l'isolation des données avec deux comptes, ajouter les politiques de confidentialité/conditions/support, et seulement ensuite déployer et préparer le paiement.

Consulter `docs/DEPLOIEMENT_SECURITE.md` pour la checklist complète. Ne jamais mettre une clé Supabase `service_role` dans le navigateur ou dans `.env.local` avec un préfixe `NEXT_PUBLIC_`.

## CRM Supabase — version 0.2

Le module CRM propose maintenant un formulaire de création et une action de suppression pour les contacts d'un utilisateur authentifié. Les opérations utilisent la session Supabase du navigateur et dépendent des politiques RLS définies dans `supabase/schema.sql`. La recherche du tableau filtre les contacts chargés.

Limites connues : la modification d'un contact n'est pas encore disponible ; en mode démo, les contacts affichés sont fictifs et le formulaire est désactivé pour éviter de laisser croire qu'une sauvegarde a été faite. Compiler et tester avec un projet Supabase de test avant tout déploiement public.


## CRM Supabase — version 0.2

Le module CRM propose maintenant un formulaire de création et une action de suppression pour les contacts d’un utilisateur authentifié. Les opérations utilisent la session Supabase du navigateur et dépendent des politiques RLS définies dans `supabase/schema.sql`. La recherche du tableau filtre les contacts chargés.

Limites connues : la modification d’un contact n’est pas encore disponible ; en mode démo, les contacts affichés sont fictifs et le formulaire est désactivé pour éviter de laisser croire qu’une sauvegarde a été faite. Compiler et tester avec un projet Supabase de test avant tout déploiement public.

## Mise à jour v5.2 — module Projets

Le module Projets charge les projets de l'utilisateur depuis `public.projects` lorsqu'une session Supabase est active. Il permet de créer un projet, modifier son statut et sa progression, et supprimer un projet. En mode démo, des exemples en lecture seule sont affichés.

### Configuration nécessaire
1. Créez un projet Supabase et renseignez `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY` dans `.env.local`.
2. Exécutez `supabase/schema.sql` dans le SQL Editor de Supabase.
3. Activez la confirmation e-mail selon vos besoins et configurez les URL de redirection d'authentification.
4. Lancez `npm install`, puis `npm run build` et corrigez toute erreur avant le déploiement.

Le module Projets n'a pas été testé de bout en bout contre un projet Supabase réel dans cet environnement. Les données restent protégées uniquement si le schéma et les politiques RLS sont appliqués correctement.

## Module Marketing — version 5.3

Le calendrier marketing permet maintenant de créer des contenus avec titre, canal, format, date prévue, statut, objectif, accroche, message principal et appel à l'action. Le statut peut être modifié depuis chaque carte et un contenu peut être supprimé après confirmation. En mode démonstration, les éléments sont conservés dans le stockage local du navigateur ; avec Supabase configuré et une session authentifiée, les opérations utilisent `marketing_contents` et ses politiques RLS.

**Validation :** l'archive a été vérifiée. La compilation complète n'a pas pu être validée dans l'environnement courant, car les dépendances npm ne sont pas installées et leur installation a expiré. Exécuter `npm install`, puis `npm run build` dans un environnement réseau disponible avant tout déploiement.

## Mise à jour v5.4 — objectifs et bibliothèque de ressources

Les espaces **Objectifs & KPI** et **Ressources** disposent maintenant de formulaires et d'actions CRUD de base :
- objectifs : créer, modifier la valeur réelle suivie et supprimer ; progression calculée à partir de la cible ;
- ressources : créer et supprimer des liens, modèles, checklists, procédures et notes ;
- mode démo : données enregistrées dans `localStorage` sur le navigateur courant ;
- mode connecté : lecture et écritures via Supabase avec `user_id` et politiques RLS, si le schéma a été appliqué.

### Vérification de cette version
L'archive a été créée à partir des sources disponibles et le contrôle TypeScript a été lancé. Il ne peut pas être considéré comme réussi car les dépendances npm ne sont pas présentes et leur installation a expiré. Les erreurs de résolution de `react`, `next`, `lucide-react` et `@supabase/supabase-js` empêchent de confirmer le typage et la compilation. Exécuter `npm install`, puis `npm run build` dans un environnement disposant d'un accès au registre npm avant tout déploiement public.

## Mise à jour v5.5 — tableau de bord dynamique

Le tableau de bord calcule maintenant ses cartes à partir des données en mémoire chargées par les modules : nombre de contacts présents, tâches ouvertes, projets en cours, somme des valeurs estimées du CRM et progression du premier objectif. La liste de projets et la liste des derniers contacts utilisent les tableaux de données des modules plutôt que des listes codées en dur. Les états vides sont affichés lorsqu'aucune donnée n'existe.

**Limite de validation :** une tentative d'installation des dépendances a expiré dans cet environnement. La compilation de production n'est donc pas certifiée. Avant un déploiement, exécuter `npm install` puis `npm run build` et corriger toute erreur révélée. Les chiffres du mode démo restent fictifs et ne doivent pas être présentés comme des résultats réels.

## Vérification locale du dépôt

Une vérification statique reproductible est disponible :

```bash
npm run verify
```

Elle contrôle la présence des dépendances et variables d'environnement attendues, les références aux six tables Supabase, la présence des règles RLS dans le schéma, l'authentification et l'absence de clé `service_role` dans le code client. Cette vérification **ne remplace pas** `npm run build`, les tests de navigateur, ni un test d'isolation réel entre deux comptes Supabase.

État au 17 octobre 2026 : `npm run verify` passe les contrôles statiques du dépôt et les vérifications d’intégrité des ressources. La compilation de production reste non vérifiée dans cet environnement car l'installation des dépendances a expiré.

## Positionnement produit — application gratuite du pack

NOTION BUSINESS OS est une composante gratuite du pack complet de produits digitaux pour entrepreneurs ; elle n'est pas vendue séparément et ne doit pas imposer d'abonnement. Voir `docs/INTEGRATION_PACK.md` pour l'architecture du pack et la liste des ressources à intégrer. Les guides, templates et bonus ne doivent être présentés comme livrés que lorsque leurs fichiers finaux ont été ajoutés et vérifiés.

### Bibliothèque du pack complet

La section Ressources présente le catalogue de départ du pack complet et distingue clairement les produits à intégrer des ressources réellement ajoutées par l'utilisateur. Aucun bouton de téléchargement fictif n'est affiché : il faut rattacher puis vérifier chaque fichier final avant de le distribuer.


## BUSINESS SUITE ULTIMATE — bibliothèque du pack

La bibliothèque regroupe les dix composantes prévues : cinq outils Excel (PROSPECT PRO, FINANCE PRO, STOCK PRO, MARKETING PRO, BUSINESS MANAGER PRO), BUSINESS PLANNER PRO, BUSINESS WORKBOOK PRO, MARKETING DESIGN KIT PRO, AI PROMPT LIBRARY et l’application web gratuite NOTION BUSINESS OS. Les fichiers Excel/PDF disponibles sont conservés dans `private-assets/`, puis téléversés dans un bucket Supabase Storage privé et servis via des liens signés temporaires. Le Pack MLM ACCÉLÉRATEUR et les produits « 100 idées de business en ligne » / « 100 templates WhatsApp » sont des projets distincts et ne doivent pas être ajoutés au catalogue de cette suite.

Les fichiers ne sont plus servis directement depuis `public/`. Le bucket privé doit être configuré et les ressources téléversées avec `npm run upload:assets` avant de tester les téléchargements.


## Contrôle d'intégrité des ressources — v6.3

La commande `npm run verify` exécute maintenant deux contrôles : les vérifications statiques du projet, puis `scripts/verify-assets.mjs`. Le second contrôle vérifie la signature des PDF et la structure ZIP des cinq classeurs XLSX. Au dernier lancement, les 10 ressources ont passé ces contrôles d'intégrité. Cela ne valide pas leur contenu métier ni leur ouverture dans Excel/Adobe Reader.

Des en-têtes HTTP de sécurité de base sont configurés dans `next.config.ts` (nosniff, protection contre l'intégration en iframe, politique de référent et permissions). Ils ne remplacent pas un audit de sécurité.

**Important avant publication :** les ressources sont dans `private-assets/` et ne sont pas directement servies par Next.js. Il faut configurer le bucket privé Supabase, lancer `npm run upload:assets`, puis tester les téléchargements. La compilation de production reste à valider.

## Stockage privé des ressources — v6.4

Les fichiers de la suite sont maintenant conservés dans `private-assets/` et ne sont plus servis directement depuis `public/`. Le point d'accès `POST /api/download` exige une session Supabase valide, vérifie l'utilisateur côté serveur, puis contrôle un droit actif dans `download_entitlements` avant de créer une URL signée de 90 secondes dans le bucket privé `business-suite-assets`. Un compte connecté sans droit reçoit `403`. Les droits doivent être attribués par un processus serveur ou un administrateur après vérification du paiement ; aucun webhook de paiement n'est encore intégré.

### Configurer le stockage privé

1. Créez un projet Supabase et renseignez `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY` dans `.env.local`.
2. Ajoutez `SUPABASE_SERVICE_ROLE_KEY` uniquement dans les variables d'environnement serveur (hébergeur ou environnement local). Ne la mettez jamais dans le code client ni dans une variable `NEXT_PUBLIC_*`.
3. Depuis la racine du projet, exécutez `npm run upload:assets`. Le script crée le bucket privé `business-suite-assets` s'il n'existe pas, puis téléverse les dix ressources depuis `private-assets/`.
4. Exécutez `npm run verify`, `npm run build`, puis testez un téléchargement sans session (`401`), avec session mais sans droit (`403`), avec droit actif mais stockage indisponible (`503`) et avec droit actif et stockage opérationnel (URL signée temporaire). Consultez `docs/SECURITE_TELECHARGEMENTS.md` pour l'attribution manuelle d'un droit de test.

Le script d'upload utilise la clé de service et doit être lancé uniquement dans un environnement de confiance. Ne déployez pas tant que le test de production n'a pas été effectué.

## Qualité continue

Le workflow `.github/workflows/quality.yml` exécute automatiquement l’installation des dépendances, `npm run verify` et `npm run build` à chaque push et pull request GitHub. Le workflow n'a pas encore été exécuté par GitHub depuis cet environnement : il devra être déclenché après publication du dépôt.


### Renforcement récent des assertions RLS
Le script `supabase/tests/security-assertions.sql` vérifie aussi qu’aucune policy supplémentaire n’est présente sur les tables métier/profil. En PostgreSQL, les policies permissives peuvent se combiner avec OR ; une policy large ajoutée par inadvertance peut donc annuler l’intention d’une policy de propriété. Exécutez ces assertions sur un projet de test après `schema.sql`.

## Déploiement Vercel + Supabase

Consultez [`docs/DEPLOIEMENT_VERCEL_SUPABASE.md`](docs/DEPLOIEMENT_VERCEL_SUPABASE.md) pour le parcours complet : migration SQL, dépôt GitHub privé, variables d’environnement Vercel, bucket Storage privé et tests de sécurité avant pilote.

## Initialiser Supabase

1. Créez un projet Supabase et copiez `.env.example` vers `.env.local`.
2. Renseignez l’URL du projet, la clé publique/anon et la clé `service_role` uniquement dans l’environnement serveur local. Ne commitez jamais `.env.local` et ne partagez jamais la clé `service_role`.
3. Vérifiez les variables avec `npm run supabase:check-env`.
4. Dans le SQL Editor du projet de test, exécutez `supabase/migrations/20261017000000_initial_schema.sql`, puis `supabase/tests/security-assertions.sql`.
5. Définissez les mêmes variables dans l’hébergeur de l’application. `SUPABASE_SERVICE_ROLE_KEY` doit être une variable serveur, sans préfixe `NEXT_PUBLIC_`.
6. Après configuration du bucket, exécutez `npm run upload:assets` dans un environnement sûr où la clé serveur est définie.

`supabase/config.toml` fournit une configuration de départ pour Supabase CLI/local development. Cela ne crée ni ne configure automatiquement un projet hébergé. La validation finale doit être effectuée sur un projet de test réel.


## Connexion au projet Supabase

Le fichier `.env.example` contient l’URL et la clé publique du projet actuellement préparé. Copiez-le vers `.env.local` à la racine du projet, puis configurez `SUPABASE_SERVICE_ROLE_KEY` uniquement avec la clé secrète serveur disponible dans Supabase Dashboard → Project Settings → API Keys. Ne partagez jamais cette clé et ne la préfixez jamais par `NEXT_PUBLIC_`.

Avant les tests, appliquez la migration SQL du dossier `supabase/migrations`, exécutez `npm run supabase:check-env`, puis les assertions de sécurité dans `supabase/tests/security-assertions.sql`. L’URL et la clé publique ne suffisent pas à déployer le schéma ni à téléverser les fichiers.
