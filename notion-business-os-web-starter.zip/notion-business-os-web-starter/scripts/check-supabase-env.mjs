const required = [
  ['NEXT_PUBLIC_SUPABASE_URL', process.env.NEXT_PUBLIC_SUPABASE_URL],
  ['NEXT_PUBLIC_SUPABASE_ANON_KEY', process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY],
  ['SUPABASE_SERVICE_ROLE_KEY', process.env.SUPABASE_SERVICE_ROLE_KEY],
];
let failed = false;
for (const [name, value] of required) {
  const placeholder = !value || /YOUR_|CHANGE_ME|PLACEHOLDER|REMPLACER|CONFIGURER|COLLER_ICI/i.test(value);
  console.log(`${placeholder ? 'MISSING' : 'OK'} ${name}`);
  if (placeholder) failed = true;
}
if (process.env.NEXT_PUBLIC_SUPABASE_URL && !/^https:\/\/[a-z0-9-]+\.supabase\.co$/i.test(process.env.NEXT_PUBLIC_SUPABASE_URL)) {
  console.error('NEXT_PUBLIC_SUPABASE_URL doit être l’URL HTTPS du projet Supabase.');
  failed = true;
}
if (failed) {
  console.error('\nConfiguration Supabase incomplète. Copiez .env.example vers .env.local et remplissez les variables. Ne partagez jamais SUPABASE_SERVICE_ROLE_KEY.');
  process.exit(1);
}
console.log('\nVariables présentes. Cela ne prouve pas encore que les identifiants fonctionnent ni que le schéma est appliqué.');
