import { readFileSync, existsSync } from 'node:fs';
import { join } from 'node:path';

const root = process.cwd();
const read = (path) => readFileSync(join(root, path), 'utf8');
const failures = [];
const checks = [];
const check = (label, ok, detail = '') => {
  checks.push({ label, ok, detail });
  if (!ok) failures.push(label);
};

const pkg = JSON.parse(read('package.json'));
const page = read('src/app/page.tsx');
const schema = read('supabase/schema.sql');
const envExample = read('.env.example');
const readme = read('README.md');

check('Next.js build script present', Boolean(pkg.scripts?.build));
check('Supabase JS dependency present', Boolean(pkg.dependencies?.['@supabase/supabase-js']));
check('Environment template has Supabase URL', envExample.includes('NEXT_PUBLIC_SUPABASE_URL='));
check('Environment template has anon key', envExample.includes('NEXT_PUBLIC_SUPABASE_ANON_KEY='));
check('Auth uses password sign-in', page.includes('signInWithPassword'));
check('Auth supports signup', page.includes('auth.signUp'));
check('No service-role key in client source', !/SERVICE_ROLE|service_role/i.test(page));
check('Private download API route exists', existsSync(join(root, 'src/app/api/download/route.ts')));
check('Private asset upload script exists', existsSync(join(root, 'scripts/upload-private-assets.mjs')));
check('Server env template includes service-role key', envExample.includes('SUPABASE_SERVICE_ROLE_KEY='));
check('Supabase CLI config exists', existsSync(join(root, 'supabase/config.toml')));
check('Initial schema is available as a migration', existsSync(join(root, 'supabase/migrations/20261017000000_initial_schema.sql')) && read('supabase/migrations/20261017000000_initial_schema.sql') === schema);
check('Environment preflight script exists', existsSync(join(root, 'scripts/check-supabase-env.mjs')) && pkg.scripts?.['supabase:check-env'] === 'node scripts/check-supabase-env.mjs');
check('Git ignores local secrets but keeps example env', read('.gitignore').includes('.env.local') && read('.gitignore').includes('!.env.example'));
check('Download route validates user session', read('src/app/api/download/route.ts').includes('auth.getUser(token)'));
check('Download route uses signed URLs', read('src/app/api/download/route.ts').includes('createSignedUrl'));
check('Download route checks server-side entitlement', read('src/app/api/download/route.ts').includes("from('download_entitlements')"));
check('Download route rejects missing entitlement', read('src/app/api/download/route.ts').includes('status: 403'));
check('Download route excludes expired entitlements', read('src/app/api/download/route.ts').includes('expires_at.gt.'));
check('Entitlement table exists in schema', /create table if not exists public\.download_entitlements/i.test(schema));
check('Entitlement table has RLS and no client policy', /alter table public\.download_entitlements enable row level security/i.test(schema) && !/create policy[^;]+on public\.download_entitlements/i.test(schema));
const securityTest = read('supabase/tests/security-smoke-test.sql');
check('Security smoke test includes entitlement RLS', securityTest.includes("c.relname = 'download_entitlements'") && securityTest.includes('client_policy_count = 0'));
check('Security smoke test inspects entitlement policies', securityTest.includes("tablename in ('profiles','contacts','projects','tasks','marketing_contents','goals','resources','download_entitlements')"));
const securityAssertions = read('supabase/tests/security-assertions.sql');
check('SQL security assertions cover all eight tables', ['profiles','contacts','projects','tasks','marketing_contents','goals','resources','download_entitlements'].every((table) => securityAssertions.includes(`'${table}'`)));
check('SQL security assertions fail when entitlement policies exist', securityAssertions.includes('if policy_count <> 0 then') && securityAssertions.includes('raise exception'));
check('SQL security assertions verify user ownership policies', securityAssertions.includes('auth.uid()') && securityAssertions.includes('with_check like'));
check('SQL security assertions reject extra permissive policies', securityAssertions.includes('policies supplémentaires potentiellement permissives') && securityAssertions.includes('policy_count <> 1'));
check('Download route fails closed on entitlement lookup errors', read('src/app/api/download/route.ts').includes('if (entitlementError)') && read('src/app/api/download/route.ts').includes('status: 503'));
check('Private bucket is not public', read('scripts/upload-private-assets.mjs').includes('public: false'));
check('No pack assets left in public directory', !existsSync(join(root, 'public/downloads')));
check('Catalog no longer links directly to public downloads', !page.includes("href:'/downloads/"));

const tables = ['contacts', 'projects', 'tasks', 'marketing_contents', 'goals', 'resources'];
for (const table of tables) {
  check(`SQL table ${table} declared`, new RegExp(`create table if not exists public\\.${table}\\b`, 'i').test(schema));
  check(`SQL enables RLS for ${table}`, new RegExp(`'${table}'`).test(schema) && /enable row level security/i.test(schema));
  check(`Client references ${table}`, page.includes(`from('${table}')`));
}
check('RLS policy checks authenticated user ownership', /auth\.uid\(\)\s*=\s*user_id/.test(schema));
check('Profile trigger is documented in schema', schema.includes('on_auth_user_created'));
check('README includes deployment/security guide', readme.includes('DEPLOIEMENT_SECURITE.md') || existsSync(join(root, 'docs/DEPLOIEMENT_SECURITE.md')));
const deploymentGuide = read('docs/DEPLOIEMENT_SECURITE.md');
check('Deployment guide documents eight-table RLS checks', deploymentGuide.includes('huit tables'));
check('Deployment guide contains download API test matrix', deploymentGuide.includes('Matrice de test de l’API de téléchargement') && deploymentGuide.includes('`403`') && deploymentGuide.includes('`503`'));
check('No committed .env.local file', !existsSync(join(root, '.env.local')));
const entitlementRunbook = read('supabase/admin-entitlements.sql');
check('Admin entitlement runbook exists', existsSync(join(root, 'supabase/admin-entitlements.sql')));
check('Admin runbook documents grant, verify and revoke', entitlementRunbook.includes('ACCORDER / RÉACTIVER') && entitlementRunbook.includes('VÉRIFIER') && entitlementRunbook.includes('RÉVOQUER'));
check('Admin runbook leaves action statements commented by default', !/^insert into public\.download_entitlements/im.test(entitlementRunbook) && !/^update public\.download_entitlements/im.test(entitlementRunbook));
check('Download security guide references admin runbook', read('docs/SECURITE_TELECHARGEMENTS.md').includes('supabase/admin-entitlements.sql'));

const packFiles = [
  'PROSPECT_PRO_Premium_Avance.xlsx',
  'FINANCE_PRO_Premium.xlsx',
  'STOCK_PRO_Premium.xlsx',
  'MARKETING_PRO_Premium.xlsx',
  'BUSINESS_MANAGER_PRO_Premium.xlsx',
  'BUSINESS_PLANNER_PRO.pdf',
  'BUSINESS_WORKBOOK_PRO.pdf',
  'MARKETING_DESIGN_KIT_PRO_Catalogue_45_Modeles.pdf',
  'MARKETING_DESIGN_KIT_PRO_Guide_Canva.pdf',
  'AI_PROMPT_LIBRARY_100_PROMPTS_PREMIUM.pdf',
];
for (const file of packFiles) {
  check(`Pack file exists: ${file}`, existsSync(join(root, 'private-assets', file)));
}
check('Library has corrected Business Suite catalog', page.includes('BUSINESS SUITE ULTIMATE') && page.includes('PROSPECT PRO') && page.includes('AI PROMPT LIBRARY'));
check('Library excludes unrelated MLM bundle', !page.includes('Pack MLM ACCÉLÉRATEUR') && !page.includes('100 SCRIPTS MLM'));
check('Library excludes unrelated WhatsApp templates product', !page.includes('100 templates WhatsApp'));
const downloadRoute = read('src/app/api/download/route.ts');
const downloadIds = [
  'prospect-pro', 'finance-pro', 'stock-pro', 'marketing-pro', 'business-manager-pro',
  'business-planner-pro', 'business-workbook-pro', 'marketing-design-catalogue',
  'marketing-design-canva-guide', 'ai-prompt-library',
];
for (const id of downloadIds) {
  check(`Private download route maps ${id}`, downloadRoute.includes(`'${id}'`));
}
const workflow = read('.github/workflows/quality.yml');
check('CI workflow runs production build', existsSync(join(root, '.github/workflows/quality.yml')) && workflow.includes('npm run build'));
check('CI does not require a missing npm lockfile for cache', !workflow.includes('cache: npm') || existsSync(join(root, 'package-lock.json')));
check('CI installs dependencies before verification', workflow.indexOf('npm install') < workflow.indexOf('npm run verify'));
check('CI verifies before production build', workflow.indexOf('npm run verify') < workflow.indexOf('npm run build'));



for (const item of checks) {
  console.log(`${item.ok ? 'PASS' : 'FAIL'}  ${item.label}`);
}
console.log(`\n${checks.filter((x) => x.ok).length}/${checks.length} checks passed.`);
if (failures.length) process.exit(1);
