import { readFileSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';

const root = process.cwd();
const files = [
  ['PROSPECT_PRO_Premium_Avance.xlsx', 'zip'],
  ['FINANCE_PRO_Premium.xlsx', 'zip'],
  ['STOCK_PRO_Premium.xlsx', 'zip'],
  ['MARKETING_PRO_Premium.xlsx', 'zip'],
  ['BUSINESS_MANAGER_PRO_Premium.xlsx', 'zip'],
  ['BUSINESS_PLANNER_PRO.pdf', 'pdf'],
  ['BUSINESS_WORKBOOK_PRO.pdf', 'pdf'],
  ['MARKETING_DESIGN_KIT_PRO_Catalogue_45_Modeles.pdf', 'pdf'],
  ['MARKETING_DESIGN_KIT_PRO_Guide_Canva.pdf', 'pdf'],
  ['AI_PROMPT_LIBRARY_100_PROMPTS_PREMIUM.pdf', 'pdf'],
];
let failures = 0;
for (const [name, kind] of files) {
  const path = join(root, 'private-assets', name);
  try {
    const stat = statSync(path);
    const data = readFileSync(path);
    const signatureOk = kind === 'pdf'
      ? data.subarray(0, 5).toString('ascii') === '%PDF-'
      : data.subarray(0, 2).equals(Buffer.from([0x50, 0x4b]));
    if (!stat.isFile() || stat.size < 100 || !signatureOk) throw new Error('taille ou signature invalide');
    if (kind === 'zip') {
      // XLSX is an Open Packaging Convention ZIP; test archive structure using the system unzip tool.
      execFileSync('unzip', ['-t', path], { stdio: 'ignore' });
    }
    console.log(`PASS ${name} (${Math.round(stat.size / 1024)} Ko)`);
  } catch (err) {
    failures++;
    console.error(`FAIL ${name}: ${err.message}`);
  }
}
console.log(`\n${files.length - failures}/${files.length} assets passed file-integrity checks.`);
if (failures) process.exit(1);
