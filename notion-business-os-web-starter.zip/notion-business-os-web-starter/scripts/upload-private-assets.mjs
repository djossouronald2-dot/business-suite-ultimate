import { createClient } from '@supabase/supabase-js';
import { readdir, readFile, stat } from 'node:fs/promises';
import { join } from 'node:path';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !serviceRoleKey) {
  console.error('Définissez NEXT_PUBLIC_SUPABASE_URL et SUPABASE_SERVICE_ROLE_KEY dans votre environnement.');
  process.exit(1);
}
const supabase = createClient(url, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } });
const bucket = 'business-suite-assets';
const { error: bucketError } = await supabase.storage.createBucket(bucket, { public: false, fileSizeLimit: '25MB' });
if (bucketError && !/already exists|duplicate/i.test(bucketError.message)) {
  console.error(`Création du bucket impossible: ${bucketError.message}`);
  process.exit(1);
}
const dir = join(process.cwd(), 'private-assets');
const files = await readdir(dir);
let failed = 0;
for (const name of files) {
  const path = join(dir, name);
  if (!(await stat(path)).isFile()) continue;
  const { error } = await supabase.storage.from(bucket).upload(name, await readFile(path), {
    upsert: true,
    contentType: name.toLowerCase().endsWith('.pdf')
      ? 'application/pdf'
      : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  if (error) { failed++; console.error(`ÉCHEC ${name}: ${error.message}`); }
  else console.log(`OK ${name}`);
}
console.log(`${files.length - failed}/${files.length} fichiers envoyés vers le bucket privé.`);
if (failed) process.exit(1);
