-- NOTION BUSINESS OS — schéma initial Supabase/PostgreSQL
-- À exécuter dans un projet Supabase neuf, puis à valider avec deux comptes de test.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  business_name text,
  full_name text,
  currency text not null default 'XOF' check (currency in ('XOF','XAF','EUR','USD')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.contacts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(trim(name)) > 0),
  company text, phone text, email text,
  contact_type text not null default 'Prospect',
  status text not null default 'Nouveau',
  source text,
  estimated_value numeric(14,2) not null default 0 check (estimated_value >= 0),
  next_follow_up date, notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (length(trim(name)) > 0),
  description text,
  status text not null default 'Planifié',
  priority text not null default 'Normale',
  due_date date, goal text,
  progress integer not null default 0 check (progress between 0 and 100),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (id, user_id)
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  project_id uuid,
  title text not null check (length(trim(title)) > 0),
  status text not null default 'À faire',
  priority text not null default 'Normale',
  due_date date, category text, notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint tasks_project_same_owner foreign key (project_id, user_id)
    references public.projects(id, user_id) on delete set null (project_id)
);

create table if not exists public.marketing_contents (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (length(trim(title)) > 0),
  channel text, format text,
  status text not null default 'Idée',
  publish_date date, objective text, hook text, main_message text, cta text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.goals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (length(trim(title)) > 0),
  period text,
  target numeric(14,2) not null default 0 check (target >= 0),
  actual numeric(14,2) not null default 0 check (actual >= 0),
  unit text, due_date date,
  status text not null default 'En cours', next_action text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.resources (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (length(trim(title)) > 0),
  resource_type text, theme text, url text, content text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Index pour les listes filtrées par utilisateur et les tris fréquents.
create index if not exists contacts_user_followup_idx on public.contacts(user_id, next_follow_up);
create index if not exists projects_user_status_idx on public.projects(user_id, status);
create index if not exists tasks_user_status_due_idx on public.tasks(user_id, status, due_date);
create index if not exists marketing_user_publish_idx on public.marketing_contents(user_id, publish_date);
create index if not exists goals_user_status_idx on public.goals(user_id, status);
create index if not exists resources_user_created_idx on public.resources(user_id, created_at desc);

-- RLS : chaque compte ne peut lire et modifier que ses propres données.
do $$ declare t text; begin
  foreach t in array array['contacts','projects','tasks','marketing_contents','goals','resources'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists %I on public.%I', t || '_own_data', t);
    execute format('create policy %I on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)', t || '_own_data', t);
  end loop;
end $$;

alter table public.profiles enable row level security;
drop policy if exists profiles_own_data on public.profiles;
create policy profiles_own_data on public.profiles for all
  using (auth.uid() = id) with check (auth.uid() = id);

-- Crée automatiquement un profil à l'inscription d'un nouvel utilisateur.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data ->> 'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();


-- Droits d'accès aux fichiers payants. Table administrée côté serveur uniquement.
create table if not exists public.download_entitlements (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_key text not null check (product_key in ('business-suite-ultimate')),
  active boolean not null default true,
  granted_at timestamptz not null default now(),
  expires_at timestamptz,
  granted_reason text,
  unique (user_id, product_key)
);

alter table public.download_entitlements enable row level security;
-- No client policies: clients cannot grant themselves access or inspect other users' entitlements.
-- The server uses SUPABASE_SERVICE_ROLE_KEY only after validating the user's session token.
create index if not exists download_entitlements_lookup_idx
  on public.download_entitlements(user_id, product_key, active);
