-- Assertions SQL: exécuter dans Supabase SQL Editor après schema.sql.
-- Le script échoue volontairement si une table attendue manque ou si les garanties RLS sont absentes.
do $$
declare
  t text;
  rls_on boolean;
  policy_count integer;
begin
  foreach t in array array['profiles','contacts','projects','tasks','marketing_contents','goals','resources','download_entitlements'] loop
    select c.relrowsecurity into rls_on
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public' and c.relname = t and c.relkind = 'r';

    if rls_on is distinct from true then
      raise exception 'SECURITY FAIL: RLS absent ou table manquante: public.%', t;
    end if;
  end loop;

  select count(*) into policy_count
  from pg_policies
  where schemaname = 'public' and tablename = 'download_entitlements';
  if policy_count <> 0 then
    raise exception 'SECURITY FAIL: download_entitlements doit avoir zéro policy client; trouvé: %', policy_count;
  end if;

  foreach t in array array['contacts','projects','tasks','marketing_contents','goals','resources'] loop
    select count(*) into policy_count
    from pg_policies
    where schemaname = 'public'
      and tablename = t
      and cmd = 'ALL'
      and qual like '%auth.uid()%'
      and qual like '%user_id%'
      and with_check like '%auth.uid()%'
      and with_check like '%user_id%';
    if policy_count <> 1 then
      raise exception 'SECURITY FAIL: une seule policy ALL de propriété utilisateur est attendue sur public.%; trouvées: %', t, policy_count;
    end if;
    select count(*) into policy_count
    from pg_policies
    where schemaname = 'public' and tablename = t;
    if policy_count <> 1 then
      raise exception 'SECURITY FAIL: policies supplémentaires potentiellement permissives sur public.%; total: %', t, policy_count;
    end if;
  end loop;

  select count(*) into policy_count
  from pg_policies
  where schemaname = 'public'
    and tablename = 'profiles'
    and cmd = 'ALL'
    and qual like '%auth.uid()%'
    and qual like '%id%'
    and with_check like '%auth.uid()%'
    and with_check like '%id%';
  if policy_count <> 1 then
    raise exception 'SECURITY FAIL: une seule policy ALL de propriété utilisateur est attendue sur public.profiles; trouvées: %', policy_count;
  end if;
  select count(*) into policy_count
  from pg_policies
  where schemaname = 'public' and tablename = 'profiles';
  if policy_count <> 1 then
    raise exception 'SECURITY FAIL: policies supplémentaires potentiellement permissives sur public.profiles; total: %', policy_count;
  end if;

  raise notice 'SECURITY PASS: RLS actif sur les huit tables; policies de propriété uniques; droits de téléchargement non accessibles aux policies client.';
end $$;
