-- NOTION BUSINESS OS — tests manuels de sécurité RLS
-- À utiliser dans un environnement de test avec deux comptes Supabase distincts.
-- Ne pas exécuter en production : les assertions nécessitent de simuler des JWT utilisateurs.
-- Procédure recommandée : créer les comptes A et B via Auth, se connecter séparément,
-- puis vérifier dans l'application que chacun ne voit que ses propres lignes.

-- Vérification des tables et de l'activation RLS (à exécuter avec un rôle administrateur) :
select n.nspname as schema_name, c.relname as table_name, c.relrowsecurity as rls_enabled
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
where n.nspname = 'public'
  and c.relname in ('profiles','contacts','projects','tasks','marketing_contents','goals','resources','download_entitlements')
order by c.relname;

-- Vérification des politiques existantes :
select schemaname, tablename, policyname, roles, cmd, qual, with_check
from pg_policies
where schemaname = 'public'
  and tablename in ('profiles','contacts','projects','tasks','marketing_contents','goals','resources','download_entitlements')
order by tablename, policyname;


-- La table des droits doit avoir RLS activé et aucune policy client :
-- les droits sont accordés uniquement par un processus serveur/administrateur de confiance.
select c.relname as table_name, c.relrowsecurity as rls_enabled,
       count(p.policyname) as client_policy_count
from pg_class c
join pg_namespace n on n.oid = c.relnamespace
left join pg_policies p on p.schemaname = n.nspname and p.tablename = c.relname
where n.nspname = 'public' and c.relname = 'download_entitlements'
group by c.relname, c.relrowsecurity;
-- Résultat attendu : rls_enabled = true et client_policy_count = 0.
