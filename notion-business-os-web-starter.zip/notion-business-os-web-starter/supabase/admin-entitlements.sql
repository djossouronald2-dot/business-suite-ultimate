-- ADMINISTRATION MANUELLE DES DROITS — BUSINESS SUITE ULTIMATE
-- À exécuter uniquement dans le SQL Editor du bon projet Supabase,
-- après avoir confirmé le paiement et l'UUID Auth exact du client.
-- Ne jamais exposer ce fichier ni les identifiants admin dans le navigateur.

-- 1) Vérifier le compte cible avant de modifier les droits :
-- select id, email, created_at
-- from auth.users
-- where id = 'REMPLACER_PAR_UUID_AUTH';
-- Vérifier que la requête retourne exactement le compte attendu.

-- 2) ACCORDER / RÉACTIVER l'accès après paiement confirmé :
-- insert into public.download_entitlements
--   (user_id, product_key, active, granted_reason, granted_at, expires_at)
-- values
--   ('REMPLACER_PAR_UUID_AUTH', 'business-suite-ultimate', true,
--    'Paiement vérifié — référence: REMPLACER_PAR_REFERENCE', now(), null)
-- on conflict (user_id, product_key) do update
-- set active = true,
--     granted_reason = excluded.granted_reason,
--     granted_at = now(),
--     expires_at = null;

-- 3) VÉRIFIER le droit après attribution :
-- select user_id, product_key, active, granted_at, expires_at, granted_reason
-- from public.download_entitlements
-- where user_id = 'REMPLACER_PAR_UUID_AUTH'
--   and product_key = 'business-suite-ultimate';

-- 4) RÉVOQUER l'accès (remplacer l'UUID avant d'exécuter) :
-- update public.download_entitlements
-- set active = false, granted_reason = 'Accès révoqué — motif: REMPLACER'
-- where user_id = 'REMPLACER_PAR_UUID_AUTH'
--   and product_key = 'business-suite-ultimate';

-- IMPORTANT : toutes les requêtes d'action restent commentées intentionnellement.
-- Décommenter uniquement la commande choisie après avoir remplacé et vérifié
-- chaque placeholder. L'activation automatique par webhook n'est pas incluse.
